# Alpha50X 5.1 — missing/stale-data correction

User-visible problems reproduced from the Windows screenshot:

- Live spot WebSocket quotes were copied into the engine only for four rotating symbols per slow REST cycle. With a ten-second poll and a five-second execution-age limit, the UI repeatedly displayed stale prices even while a stream was receiving messages.
- A long candle request could age the quote collected before it; EURUSDT conversion was also incorrectly subjected to the five-second quote limit instead of its own sixty-second FX limit.
- Archived trades were preserved in SQLite but never bound to the unified recent-trades display.
- Missing provider credentials were shown as empty modules without a usable setup path. Stock entry cost in EUR looked like the original USD entry price.

Corrections:

1. Synchronize every genuinely fresh stream quote on UI refresh and before decisions. Never change its recorded timestamp. Disconnect immediately removes executable stream quotes; retained prices stay visibly stale.
2. Reacquire quotes after slow history requests, validate at actual receipt time, and batch historical-bar persistence in one transaction.
3. Keep the last available quote visible with source, age and status. Closed-market stock quotes and daily FX reference rates are display-only and cannot pass execution validation.
4. Show the 69 archived trades separately from new fills and retain the original USD entry for imported stock positions. No transactions are replayed or manufactured.
5. Add Bulgarian readiness messages, missing-connection reasons, a local setup form and a credential-free diagnostic download. Credentials can be saved with Windows user-bound DPAPI; values are never returned by the API or exported. Existing Alpaca SDK environment names can be reused. Optional old-settings import reads only recognized fields locally in the browser.
6. Add official ECB daily cross-rates as explicitly labelled reference information without inventing bid/ask quotes. These references are not live Forex execution data.
7. Add a backtest button using at least 180 recorded, contiguous completed candles. Missing history produces an explanation; it does not produce example results.

Validation here: 332 tests discovered, 331 passed, 1 Windows-native DPAPI test skipped on Linux. Real Chromium UI smoke passed. Live provider connectivity and user-specific credentials remain a separate check; the original definition of done is still not claimed complete.

Updating preserves the working database, kill switch, existing trades and previous releases. A fresh package must be extracted and started after closing the old application window. No administrator access or security-setting changes are required.
