@echo off
setlocal EnableExtensions DisableDelayedExpansion
title Alpha50X 5.1 - Install and Start
cd /d "%~dp0"

if not exist "%~dp0alpha50x_unified_complete_installer.py" (
  echo Please extract ALL files from the ZIP into a folder first.
  echo Then double-click START_ALPHA50X.cmd in that folder.
  pause
  exit /b 1
)

set "AX_PYTHON="
for %%V in (3.12 3.14 3.13 3.11) do (
  if not defined AX_PYTHON (
    for /f "delims=" %%P in ('py -%%V -c "import sys; print(sys.executable)" 2^>nul') do set "AX_PYTHON=%%P"
  )
)
if not defined AX_PYTHON (
  if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" set "AX_PYTHON=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
)
if not defined AX_PYTHON (
  for /f "delims=" %%P in ('python -c "import sys; assert sys.version_info[:2] in [(3,11),(3,12),(3,13),(3,14)]; print(sys.executable)" 2^>nul') do set "AX_PYTHON=%%P"
)
if not defined AX_PYTHON (
  echo Python 3.12 is needed before this program can start.
  echo No existing Alpha50X files have been changed.
  echo Please tell your assistant: PYTHON NOT FOUND
  pause
  exit /b 1
)

set "AX_HOME=%LOCALAPPDATA%\Alpha50X Unified"
if not exist "%AX_HOME%" mkdir "%AX_HOME%"
if not exist "%AX_HOME%" (
  echo Cannot create the installation folder. No old project files were changed.
  pause
  exit /b 1
)

echo Alpha50X 5.1 is preparing. Please keep this window open.
echo On the first start, installing and checking can take several minutes.
echo Your previous Alpha50X folders will not be overwritten.
echo.
set "AX_SETUP_LOG=%LOCALAPPDATA%\Alpha50X-easy-install.log"
"%AX_PYTHON%" "%~dp0alpha50x_unified_complete_installer.py" --target "%AX_HOME%" > "%AX_SETUP_LOG%" 2>&1
if errorlevel 1 (
  echo Installation did not finish. It has stopped safely.
  echo Please send your assistant this file: Alpha50X-easy-install.log
  start "" notepad.exe "%AX_SETUP_LOG%"
  pause
  exit /b 1
)

echo Installation checked. Opening the Alpha50X panel.
echo Keep this window open while using the program.
echo Trades are simulated. PAPER starts OFF.
"%AX_PYTHON%" "%AX_HOME%\start_alpha50x.py"
if errorlevel 1 (
  echo The panel could not stay open. Please tell your assistant what happened.
  pause
  exit /b 1
)
exit /b 0
